let router = require("express").Router();

class Server {
    constructor() {
        //this.database = database;
    }

    Server(database) {
        router.post('/',(req,res) => {
            console.log("values are listed here")
            console.log("inputs values done");
            var logdata = req.body;
            database.insertIntoServerCollection(logdata).then(() => {
                res.send("inserted successfully")
            }).catch((err) => {
                console.log(err);
                res.send("Error while inserting data....!")
            });
        });
        return router;
    }

    Lister(database) {
        router.get('/logs',(req,res) => {
            database.ListCollectiondata().then((database) => {
                console.log('data listed successfully....')
                res.send(database);
            }).catch((err) => {
                console.log(err);
                res.send("Error while listing the data");
            });
        });
        return router;
    }
}

module.exports = Server;