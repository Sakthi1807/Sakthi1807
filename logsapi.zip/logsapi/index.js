let express = require("express");
let Database = require("./Database/index");
let Server = require("./server/index");

let app = express();
const PORT = 8080;

let dbObj = new Database();
let serverRouter = new Server();

let receivelog = serverRouter.Server(dbObj); 
let showlogdata = serverRouter.Lister(dbObj);
//view code
app.use(express.static('public'));
//routing through calls
app.use(express.json());

app.use('/home',receivelog);
app.use('/',showlogdata);

//creating the db connection
dbObj.createConnection().then(() => {
    console.log("Connection to mongo db is complete");
})

//Listener Port
app.listen(PORT);
console.log("Application stated at " + PORT);