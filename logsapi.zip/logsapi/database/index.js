let mongodb = require('mongodb').MongoClient;
let URL = "mongodb://localhost/";

class Database {
    constructor() {
        this.database = null;
    }
    // create db connection
    createConnection() {
        return new Promise((resolve, reject) => {
            mongodb.connect(URL, (err, db) => {
                if (err) {
                    reject(err);
                }
                this.database = db.db("Log-management");
                console.log("connection successful");
                resolve();
            });
        });
    }
    // to insert the data to db
    insertIntoServerCollection(server) {
        return new Promise((resolve, reject) => {
            console.log("inserting data into db")
            //console.log(server);
            this.database.collection('server').insertOne(server, (err, res) => {
                //console.log(arguments);
                if (err) reject(err);
                resolve(res);
                //console.log(res);
            });
        });
    }

    // to list the data from db to UI
    ListCollectiondata() {
        return new Promise((resolve,reject) => {
            this.database.collection('server').find({}).toArray((err,res) => {
                if(err){
                     reject(err);
                    console.log("error in listing the data")
                    console.log(err);
                }
                else {
                    resolve(res);
                    console.log(res);
                }
            });
        });
    }
}

module.exports = Database;